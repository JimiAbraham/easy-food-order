
<?php
session_start();
require_once("dbcontroller.php");
$db_handle = new DBController();
if(!empty($_GET["action"])) {
switch($_GET["action"]) {
    case "add":
        if(!empty($_POST["quantity"])) {
            $productByCode = $db_handle->runQuery("SELECT * FROM products WHERE code='" . $_GET["code"] . "'");
            $itemArray = array($productByCode[0]["code"]=>array('name'=>$productByCode[0]["name"], 'code'=>$productByCode[0]["code"], 'quantity'=>$_POST["quantity"], 'price'=>$productByCode[0]["price"], 'image'=>$productByCode[0]["image"]));
            
            if(!empty($_SESSION["cart_item"])) {
                if(in_array($productByCode[0]["code"],array_keys($_SESSION["cart_item"]))) {
                    foreach($_SESSION["cart_item"] as $k => $v) {
                            if($productByCode[0]["code"] == $k) {
                                if(empty($_SESSION["cart_item"][$k]["quantity"])) {
                                    $_SESSION["cart_item"][$k]["quantity"] = 0;
                                }
                                $_SESSION["cart_item"][$k]["quantity"] += $_POST["quantity"];
                            }
                    }
                } else {
                    $_SESSION["cart_item"] = array_merge($_SESSION["cart_item"],$itemArray);
                }
            } else {
                $_SESSION["cart_item"] = $itemArray;
            }
        }
    break;
    case "remove":
        if(!empty($_SESSION["cart_item"])) {
            foreach($_SESSION["cart_item"] as $k => $v) {
                    if($_GET["code"] == $k)
                        unset($_SESSION["cart_item"][$k]);              
                    if(empty($_SESSION["cart_item"]))
                        unset($_SESSION["cart_item"]);
            }
        }
    break;
    case "empty":
        unset($_SESSION["cart_item"]);
    break;  
}
}
?>


<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>FoodKapp - Food Ordering, Delivery Mobile Template</title>
    <!--fivicon icon-->
    <link rel="icon" href="assets/img/fevicon.png">

    <!-- Stylesheet -->
    <link rel="stylesheet" href="assets/css/animate.min.css">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/magnific.min.css">
    <link rel="stylesheet" href="assets/css/jquery-ui.min.css">
    <link rel="stylesheet" href="assets/css/nice-select.min.css">
    <link rel="stylesheet" href="assets/css/owl.min.css">
    <link rel="stylesheet" href="assets/css/slick-slide.min.css">
    <link rel="stylesheet" href="assets/css/fontawesome.min.css">
    <link rel="stylesheet" href="assets/css/remixicon/remixicon.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/responsive.css">

    <!--Google Fonts-->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&amp;display=swap" rel="stylesheet">


</head>
<body class='sc5'>
    <!-- preloader area start -->
    <div class="preloader" id="preloader">
        <div class="preloader-inner">
            <div id="wave1">
            </div>
            <div class="spinner">
                <div class="dot1"></div>
                <div class="dot2"></div>
            </div>
        </div>
    </div>
    <!-- preloader area end -->

    <!-- search popup area start -->
    <div class="body-overlay" id="body-overlay"></div>
    <div class="td-search-popup" id="td-search-popup">
        <form action="https://themefie.com/html/foodkapp/index.html" class="search-form">
            <div class="form-group">
                <input type="text" class="form-control" placeholder="Search.....">
            </div>
            <button type="submit" class="submit-btn"><i class="fa fa-search"></i></button>
        </form>
    </div>
    <!-- //. search Popup -->
    
    <div class="container">
        <div class="main-home-area pb-0 mt-5">
            <div class="location-area">
                <div class="media">
                    <img src="assets/img/icon/map-marker.svg" alt="img">
                    <div class="media-body">
                        <span>We deliver via Ride</span>
                        <select class="single-select">
                            <option>Lagos Nigera</option>
                            <option value="asc">Dhaka, Bangladesh</option>
                        </select>
                    </div>
                </div>
                <a class="notification-btn" href="#"><img src="assets/img/icon/notification.svg" alt="icon"></a>
            </div>
            <div class="home-search-wrap">
                <div class="default-form-wrap">
                    <div class="single-input-wrap">
                        <label><img src="assets/img/icon/search.svg" alt="img"></label>
                        <input type="text" class="form-control" placeholder="Search for food">
                    </div>
                    <button type="button" class="btn btn-border" data-bs-toggle="modal" data-bs-target="#exampleModal">
                        <img src="assets/img/icon/filter.svg" alt="img">
                    </button>
                </div>
            </div>   
        </div>
    </div>
    <div class="banner-slider-wrap">
        <div class="banner-slider owl-carousel">
            <div class="item">
                <img src="assets/img/banner/1.png" alt="img">
            </div>
            <div class="item">
                <img src="assets/img/banner/2.png" alt="img">
            </div>
            <div class="item">
                <img src="assets/img/banner/3.png" alt="img">
            </div>
        </div> 
    </div> 

   <center> <a id="btnEmpty" href="index.php?action=empty">Empty Cart</a></center>
 <?php
if(isset($_SESSION["cart_item"])){
    $total_quantity = 0;
    $total_price = 0;
?>
<div style="overflow: scroll;">
<table class="tbl-cart" cellpadding="10" cellspacing="1">
<tbody>
<tr>
<th style="text-align:left;">Name</th>
<!-- <th style="text-align:left;">Code</th>
 --><th style="text-align:right;" width="5%">Quantity</th>
<th style="text-align:right;" width="10%">Unit Price</th>
<th style="text-align:right;" width="10%">Price</th>
<th style="text-align:center;" width="5%">Remove</th>
</tr>   
<?php       
    foreach ($_SESSION["cart_item"] as $item){ 

        $item_price = $item["quantity"]*$item["price"];

       // $op_name =  '<input type="text"  id= "food_name" name="food_name" value="'.$item['name'].'">';
        // $op_price =  '<input type="text" id= "food_price" name="food_price" value="'.$item_price.'">';

        // $op_qty =  '<input type="text" id= "food_qty" name="food_qty" value="'.$item["quantity"].'">';

            $op_name[] =  $item['name'];

              $op_price[] =  $item_price;

         $op_qty[] =  $item["quantity"];

        ?>
                <tr>
                <td><?php echo $item["name"]; ?></td>
<!--                 <td><?php echo $item["code"]; ?></td>
 -->                <td style="text-align:center;"><?php echo $item["quantity"]; ?></td>
                <td  style="text-align:right;"><?php echo "".$item["price"]; ?></td>
                <td  style="text-align:right;"><?php echo "". number_format($item_price,2); ?></td>
                <td style="text-align:center;"><a href="index.php?action=remove&code=<?php echo $item["code"]; ?>" class="btnRemoveAction"><img src="icon-delete.png" alt="Remove Item" /></a></td>
                </tr>
                <?php
                $total_quantity += $item["quantity"];
                $total_price += ($item["price"]*$item["quantity"]);

            echo '<form id="formOrder" action="newpage.php" method="POST">';

         
              // print_r($op_name);
              // echo '<br>';
              print_r($op_qty);
              // echo '<br>';
              // print_r($op_price);
              // echo '<br>';
foreach ( $op_name as $food => $f )
echo $f .'<br>';
                    
                    };

        echo 'Total='.$total_price;

       


        ?>




<tr>
<td colspan="2" align="right">Total:</td>
<td align="right"><?php echo $total_quantity; ?></td>
<td align="right" colspan="2"><strong><?php echo "N ".number_format($total_price, 2); ?></strong></td>
<td></td>
</tr>


</tbody>
</table>  
<!-- <form>
            <input type="text" value="<?php echo $total_price; ?>">
            <input type="text" value="<?php echo $total_quantity; ?>">

            <?php   echo $op;  ?>
            <input type="submit">
        </form> -->
</div>      
  <?php
} else {
?>
<center><div class="no-records">Your Cart is Empty</div></center>
<?php 
}
?>
</div>
    <div class="container">
        <div class="main-home-area pt-0">            
            <div class="home-category-slider owl-carousel">
                <div class="item">
                    <a class="home-category-item-wrap" href="single-page.html">
                        <img src="assets/img/category/ramen.png" alt="img">
                        Ramen
                    </a>
                </div>
                <div class="item">
                    <a class="home-category-item-wrap" href="single-page.html">
                        <img src="assets/img/category/pizza.png" alt="img">
                        Pizza
                    </a>
                </div>
                <div class="item">
                    <a class="home-category-item-wrap" href="single-page.html">
                        <img src="assets/img/category/burger.png" alt="img">
                        Burger
                    </a>
                </div>
                <div class="item">
                    <a class="home-category-item-wrap" href="single-page.html">
                        <img src="assets/img/category/drink.png" alt="img">
                        Soft Drinks
                    </a>
                </div>
                <div class="item">
                    <a class="home-category-item-wrap" href="single-page.html">
                        <img src="assets/img/category/fast-food.png" alt="img">
                        Fast Food
                    </a>
                </div>
                <div class="item">
                    <a class="home-category-item-wrap" href="single-page.html">
                        <img src="assets/img/category/french-fries.png" alt="img">
                        French Fries
                    </a>
            </div> 
                </div>
            <h5 class="section-title">Nearby Restaurant</h5>

            <?php
    $product_array = $db_handle->runQuery("SELECT * FROM products ORDER BY id ASC");
    if (!empty($product_array)) { 
        foreach($product_array as $key=>$value){
    ?>
           
         <div class="single-product-wrap">
                <div class="thumb">

     <form method="post" action="index.php?action=add&code=<?php echo $product_array[$key]["code"]; ?>">

                    <span class="tag">15% Off</span>
                    <a href="">
                        <img alt="Food Pic" src="product-images/<?php echo $product_array[$key]["image"]; ?>">
                    </a>
                    <a class="fav-btn" href="#"><i class="fa fa-heart"></i></a>
                </div>
                <div class="details">
                    <h6><a href=""><?php echo $product_array[$key]["name"]; ?></a> <span><?php echo "N".$product_array[$key]["price"]; ?></span></h6>
                    
                    <span><?php echo $product_array[$key]["code"]; ?></span>
                     <br>
                    <div class="ratting">
                        <i class="ri-star-fill ps-0"></i>Qty
                        <span><input type="number"  style="width:50px" class="product-quantity" name="quantity" value="1" size="2" /></span>

                        <span ><input type="submit" value="Add to Cart" style="background-color:#ce2829; border-radius: 5px; color: white;" class="btnAddAction tag" /></span>
                    </div>
                </div>
            </div>


        <div class="product-item">
            <div class="product-image"></div>
            <div class="product-tile-footer">
            <div class="product-title"></div>
            <div class="product-price"></div>
            <div class="cart-action"></div>
            </div>
            </form>
        </div>
    <?php
        }
    }
    ?>
 </div>
            </div>



         
            
            
            
           
            
            <div class="main-footer-bottom d-block text-center">
                <ul>
                    <li>
                        <a href="main-home.html">
                            <img src="assets/img/icon/svg/home.svg" alt="icon">
                        </a>
                    </li>
                    <li>
                        <a href="search.html">
                            <img src="assets/img/icon/svg/search.svg" alt="img">
                        </a>
                    </li>
                    <li class="shop-btn">
                        <a class="menu-bar" href="cart-page.html">
                            <img src="assets/img/icon/svg/bag.svg" alt="img">
                        </a>
                    </li>
                    <li>
                        <a href="vouchers.html">
                            <img src="assets/img/icon/svg/discount.svg" alt="img">
                        </a>
                    </li>
                    <li>
                        <a href="profile.html">
                            <img src="assets/img/icon/svg/profile.svg" alt="img">
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>  

    <!-- Modal -->
    <div class="modal fade bottom filter-modal-popup" id="exampleModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="container">
                    <h5 class="section-title">Shot by</h5>
                    <div class="home-category-slider owl-carousel">
                        <div class="item">
                            <button class="home-category-item-wrap">
                                Offer
                            </button>
                        </div>
                        <div class="item">
                            <button class="home-category-item-wrap">
                                Free Delivery
                            </button>
                        </div>
                        <div class="item">
                            <button class="home-category-item-wrap">
                                Most Popular
                            </button>
                        </div>
                        <div class="item">
                            <button class="home-category-item-wrap">
                                Online Payment
                            </button>
                        </div>
                    </div> 
                    <h5 class="section-title">Category</h5>
                    <div class="home-category-slider owl-carousel">
                        <div class="item">
                            <a class="home-category-item-wrap" href="#">
                                <img src="assets/img/category/ramen.png" alt="img">
                                Ramen
                            </a>
                        </div>
                        <div class="item">
                            <a class="home-category-item-wrap" href="#">
                                <img src="assets/img/category/pizza.png" alt="img">
                                Pizza
                            </a>
                        </div>
                        <div class="item">
                            <a class="home-category-item-wrap" href="#">
                                <img src="assets/img/category/burger.png" alt="img">
                                Burger
                            </a>
                        </div>
                        <div class="item">
                            <a class="home-category-item-wrap" href="#">
                                <img src="assets/img/category/drink.png" alt="img">
                                Soft Drinks
                            </a>
                        </div>
                        <div class="item">
                            <a class="home-category-item-wrap" href="#">
                                <img src="assets/img/category/fast-food.png" alt="img">
                                Fast Food
                            </a>
                        </div>
                        <div class="item">
                            <a class="home-category-item-wrap" href="#">
                                <img src="assets/img/category/french-fries.png" alt="img">
                                French Fries
                            </a>
                        </div>
                    </div> 
                    <h5 class="section-title">Price Range</h5>
                    <ul class="price-list">
                        <li><a href="#">$</a></li>
                        <li><a href="#">$$</a></li>
                        <li><a href="#">$$$</a></li>
                        <li><a href="#">$$$$</a></li>
                    </ul>
                    <button type="button" class="link-btn" data-bs-dismiss="modal">Clear All</button>
                    <button type="button" class="btn btn-base">Apply Filters</button>
                </div>              
            </div>            
        </div>
    </div>

    

    <!-- all plugins here -->
    <script src="assets/js/jquery.3.6.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/imageloded.min.js"></script>
    <script src="assets/js/counterup.js"></script>
    <script src="assets/js/waypoint.js"></script>
    <script src="assets/js/magnific.min.js"></script>
    <script src="assets/js/isotope.pkgd.min.js"></script>
    <script src="assets/js/jquery-ui.min.js"></script>
    <script src="assets/js/nice-select.min.js"></script>
    <script src="assets/js/fontawesome.min.js"></script>
    <script src="assets/js/owl.min.js"></script>
    <script src="assets/js/slick-slider.min.js"></script>
    <script src="assets/js/wow.min.js"></script>
    <script src="assets/js/tweenmax.min.js"></script>
    <!-- main js  -->
    <script src="assets/js/main.js"></script>

    <script
  src="https://code.jquery.com/jquery-3.6.0.min.js"
  integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4="
  crossorigin="anonymous"></script>

<script type="text/javascript">
    
$(document).ready(function(){

$('#formOrder').submit(function(event){

 let fname = document.getElementById('fname').value;
 let lname = document.getElementById('lname').value;
 let email = document.getElementById('email').value;
 let password = document.getElementById('password').value;
 let phone = document.getElementById('phone').value;
let twitter = document.getElementById('twitter').value;
 let insta = document.getElementById('insta').value;
  let snap = document.getElementById('snap').value;
 let submit = document.getElementById('submit').value;

$("#msg").load('../register.php', {
    fname: fname,
    lname: lname,
    email: email,
    phone: phone,
    twitter: twitter,
    insta: insta,
    snap: snap,
    password: password,
    submit : submit

});

event.preventDefault();
})


});
</script>
</body>

</html>