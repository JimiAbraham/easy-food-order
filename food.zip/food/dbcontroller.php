<?php
class DBController {
	private $host = "localhost";
	private $user = "root";
	private $password = "";
	private $database = "shop";
	private $conn;
	
	function __construct() {
		$this->conn = $this->connectDB();
	}
	
	function connectDB() {
		$conn = mysqli_connect($this->host,$this->user,$this->password,$this->database);
		return $conn;
	}
	
	function runQuery($query) {
		$result = mysqli_query($this->conn,$query);
		while($row=mysqli_fetch_assoc($result)) {
			$resultset[] = $row;
		}		
		if(!empty($resultset))
			return $resultset;
	

	}	function numRows($query) {
		$result  = mysqli_query($this->conn,$query);
		$rowcount = mysqli_num_rows($result);
		return $rowcount;	
	}

	function add( $food_name, $food_desc, $food_price, $food_img ){




$allowed_image_extension = array(
       "png", "jpg", "jpeg"
	);
	
	$file_extension = pathinfo($_FILES["food_img"]["name"], PATHINFO_EXTENSION);
		
	if ( !in_array($file_extension, $allowed_image_extension))

	{
echo '<script> 
alert("Please upload a valid image");
 </script>';
	}elseif( ($_FILES["food_img"]["size"] > 2000000)  ){
		echo '<script> 
alert("File Size is heavy, upload light wight photo");
 </script>'; 
	}else{

$filename = $_FILES['food_img']['name'];
$uploadPath = '../product-images/' . $filename;
move_uploaded_file($_FILES['food_img']['tmp_name'], $uploadPath);


	$query = mysqli_query($this->conn,"INSERT INTO products ( name, code, price, image ) VALUES ('$food_name','$food_desc','$food_price', '$filename' )");

	if ($query){
		return true;
	}else{
		return false;
	}	


	}
}

}
?>