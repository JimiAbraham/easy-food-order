<?php 


if (isset($_POST['submit'])){

    $names = $_POST['food_name'];
    $prices = $_POST['food_price'];
    $qtys = $_POST['food_qty'];


foreach ( $names as $name);
print_r($name) ;
}

?>