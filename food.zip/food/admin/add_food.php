<?php  

include('../dbcontroller.php');


$db  = new DBController();



if (isset( $_POST['submit'])){
 $food_name = $_POST['food_name'];
 $food_desc = $_POST['food_desc'];
 $food_price = $_POST['food_price'];
 $food_img = $_FILES['food_img'];


 $run_query = $db->add( $food_name, $food_desc, $food_price, $food_img );


 if ( $run_query == true)
 {

 echo "record inserted";

}else{

	echo "Try Again";
}

}
?>


<form method="POST" action ="" enctype="multipart/form-data">

	<input type="text" name="food_name" placeholder="food name"><br><br>

    <input type="text" name="food_desc" placeholder="Short Description"><br><br>

    <input type="number" name="food_price" placeholder="Price"><br><br>

     <input type="file" name="food_img"><br><br>

     <input type="submit" name="submit" value="submit">

 
</form>